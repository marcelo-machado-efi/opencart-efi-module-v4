<?php

namespace Opencart\Catalog\Controller\Extension\Efi\Payment;


use Opencart\System\Engine\Controller;
use Opencart\System\Library\Log;

/**
 * Controller responsável por tratar o webhook do GitHub/GitLab e atualizar o plugin via git pull.
 */
class EfiGitWebhook extends Controller
{
    private Log $log;

    public function __construct($registry)
    {
        parent::__construct($registry);
        $this->log = new Log('git_webhook.log');
    }

    public function index(): void
    {
        // Segurança básica: certifique-se de configurar isso corretamente
        $sharedSecret = '860a206f103afcea941477c160b5bced'; // coloque isso em uma config segura

        $tokenHeader = $this->request->server['HTTP_X_HUB_SIGNATURE'] ?? '';
        $tokenQuery  = $this->request->get['token'] ?? '';

        if ($tokenQuery !== $sharedSecret) {
            $this->response->addHeader($this->request->server['SERVER_PROTOCOL'] . ' 403 Forbidden');
            $this->response->setOutput('Token inválido');
            return;
        }

        $this->log->write('Webhook recebido. Iniciando atualização via git pull.');

        // Caminho onde o plugin está instalado
        $pluginPath = DIR_EXTENSION . 'efi/';

        // Comando para executar
        $cmd = "cd {$pluginPath} && git reset --hard && git pull origin main 2>&1";

        exec($cmd, $output, $return_var);

        if ($return_var !== 0) {
            $this->log->write('Erro ao executar git pull: ' . implode("\n", $output));
            $this->response->setOutput('Falha ao atualizar o plugin.');
            return;
        }

        $this->log->write('Atualização do plugin concluída com sucesso.');
        $this->response->setOutput('Atualizado com sucesso via webhook.');
    }
}
